import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const shares = sqliteTable('shares', {
  id: text('id').primaryKey(),
  ciphertext: text('ciphertext').notNull(),
  iv: text('iv').notNull(),
  createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
});
export const shareLimits = sqliteTable('share_limits', {
  id: text('id').primaryKey(),
  window: integer('window').notNull(),
  count: integer('count').notNull(),
});
