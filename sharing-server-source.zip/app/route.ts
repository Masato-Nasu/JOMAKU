import html from './ceremony';
export const dynamic='force-dynamic';
export function GET(){return new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'public, max-age=60','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'}});}
