import {read,options} from '../service';
export const dynamic='force-dynamic';
export async function GET(request:Request,{params}:{params:Promise<{id:string}>}){return read(request,(await params).id);}
export const OPTIONS=options;
