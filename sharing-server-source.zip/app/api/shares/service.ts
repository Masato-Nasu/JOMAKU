import { env } from 'cloudflare:workers';
const TTL = 90 * 86400 * 1000;
const origins = new Set(['https://masato-nasu.github.io', 'https://jomaku.sunny-seed-0354.chatgpt.site', 'null']);
export function cors(request: Request) {
  const origin = request.headers.get('origin');
  return { 'Access-Control-Allow-Origin': origin && origins.has(origin) ? origin : 'https://jomaku.sunny-seed-0354.chatgpt.site', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
}
export function json(request: Request, value: unknown, status=200) { return Response.json(value, {status,headers:cors(request)}); }
export function options(request: Request) { return new Response(null,{status:204,headers:cors(request)}); }
export function encode(bytes: Uint8Array) { return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
async function boundedJson(request: Request) {
  if(Number(request.headers.get('content-length'))>500000)throw new Error('SIZE');
  const reader=request.body?.getReader();if(!reader)throw new Error('BODY');
  const chunks:Uint8Array[]=[];let size=0;
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>500000){await reader.cancel();throw new Error('SIZE');}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return JSON.parse(new TextDecoder().decode(bytes));
}
export async function create(request: Request) {
  const origin=request.headers.get('origin');if(origin&&!origins.has(origin))return json(request,{error:'許可されていない送信元です。'},403);
  if(!request.headers.get('content-type')?.includes('application/json'))return json(request,{error:'JSON形式で送信してください。'},415);
  let data;try{data=await boundedJson(request);}catch(e){return json(request,{error:e instanceof Error&&e.message==='SIZE'?'写真が大きすぎます。':'共有データを確認してください。'},400);}
  if(data?.v!==1||typeof data.ciphertext!=='string'||data.ciphertext.length<24||data.ciphertext.length>440000||!/^[A-Za-z0-9_-]+$/.test(data.ciphertext)||typeof data.iv!=='string'||!/^[A-Za-z0-9_-]{16}$/.test(data.iv))return json(request,{error:'共有データを確認してください。'},400);
  if(!env.DB)return json(request,{error:'共有の保存先を準備中です。'},503);
  try{
    const now=Date.now(),window=Math.floor(now/3600000);
    const ip=request.headers.get('cf-connecting-ip')||'unknown';
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('jomaku:'+ip));
    const limitId=encode(new Uint8Array(digest));
    const limit=await env.DB.prepare('INSERT INTO share_limits (id, window, count) VALUES (?, ?, 1) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END, window=excluded.window RETURNING count').bind(limitId,window).first<{count:number}>();
    if((limit?.count||0)>30)return json(request,{error:'共有リンクの作成が続いています。時間をおいてお試しください。'},429);
    const id=encode(crypto.getRandomValues(new Uint8Array(18))),expiresAt=now+TTL;
    await env.DB.prepare('INSERT INTO shares (id, ciphertext, iv, created_at, expires_at) VALUES (?, ?, ?, ?, ?)').bind(id,data.ciphertext,data.iv,now,expiresAt).run();
    // Cleanup is bounded; expired records are never returned even if cleanup is delayed.
    await env.DB.batch([env.DB.prepare('DELETE FROM shares WHERE id IN (SELECT id FROM shares WHERE expires_at < ? LIMIT 50)').bind(now),env.DB.prepare('DELETE FROM share_limits WHERE id IN (SELECT id FROM share_limits WHERE window < ? LIMIT 50)').bind(window-24)]);
    return json(request,{v:1,id,expiresAt},201);
  }catch(e){console.error('Share storage error',e instanceof Error?e.message:'unknown');return json(request,{error:'共有リンクを保存できませんでした。もう一度お試しください。'},503);}
}
export async function read(request:Request,id:string){
  if(!/^[A-Za-z0-9_-]{24}$/.test(id))return json(request,{error:'リンクが正しくありません。'},400);
  if(!env.DB)return json(request,{error:'共有の保存先を準備中です。'},503);
  try{const row=await env.DB.prepare('SELECT ciphertext, iv, expires_at FROM shares WHERE id=? AND expires_at>?').bind(id,Date.now()).first<{ciphertext:string,iv:string,expires_at:number}>();
    if(!row)return json(request,{error:'この除幕式は見つからないか、有効期限が切れています。'},404);
    return json(request,{v:1,ciphertext:row.ciphertext,iv:row.iv,expiresAt:row.expires_at});
  }catch{return json(request,{error:'除幕式を読み込めませんでした。通信を確認して、再読み込みしてください。'},503);}
}
