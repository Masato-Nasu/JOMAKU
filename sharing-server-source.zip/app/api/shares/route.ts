import {create,options} from './service';
export const dynamic='force-dynamic';
export const POST=create;
export const OPTIONS=options;
